package com.cg.service;

import com.cg.bean.Merchant;

public interface IMerchantService 
{
Merchant addMerchant(Merchant merchant);
Merchant getid(Integer id);
}
