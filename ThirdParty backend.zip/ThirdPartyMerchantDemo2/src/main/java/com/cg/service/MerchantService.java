package com.cg.service;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import com.cg.bean.Merchant;
import com.cg.dao.IMerchantDAO;
import com.cg.exception.ThirdPartyException;
@Service
public class MerchantService implements IMerchantService {
@Autowired private IMerchantDAO dao;
	@Transactional
	public Merchant addMerchant(Merchant merchant) {
		// TODO Auto-generated method stub
		merchant.setAddMerchantDate(new Date());
		//merchant.setMobileNumber("888810810");
		if(dao.existsById(merchant.getMerchantId()))
			throw new ThirdPartyException("Merchant is allready Exist");
		return dao.save(merchant);
	}
	@Override
	public Merchant getid(Integer id) {
		// TODO Auto-generated method stub
		if (dao.findById(id)==null) {
			throw new ThirdPartyException("Merchant is not Exist");
		}

		return dao.findById(id).get();
	}

}
