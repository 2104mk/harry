package com.cg.exception;

public class ThirdPartyException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ThirdPartyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ThirdPartyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
