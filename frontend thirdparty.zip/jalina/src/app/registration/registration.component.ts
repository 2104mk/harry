import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '../../../node_modules/@angular/router';
import { FormBuilder, FormGroup, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  RegistratoinForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, 
    private router: Router,private registratoinservice:UserService ) {}
  onSubmit() {
    this.submitted = true;
    if (this.RegistratoinForm.invalid) {
      return;
    }
    console.log(this.RegistratoinForm.value);
      this.registratoinservice.create(this.RegistratoinForm.value).subscribe(data=>{
        alert(this.RegistratoinForm.controls.merchantName.value +' registration successfull')
        //alert(this.RegistratoinForm.controls.f//value+'record is added successfully')
        this.router.navigate(['*'])
      });
  }
  ngOnInit() {
    this.RegistratoinForm = this.formBuilder.group({
      merchantName: ['', Validators.required],
      mobileNumber:['',Validators.required],
      email: ['', Validators.required],
      password: ['',Validators.required],
      catogory:['',Validators.required],
      productName: ['', Validators.required]
    });
  }

}
