export class User
{
    //id:number;
    merchantName:string;
    mobileNumber:string;
    email:string;
    password:string;
    catogory:string;
    productName:string
}