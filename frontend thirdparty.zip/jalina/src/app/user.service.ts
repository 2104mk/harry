import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './model/registration';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  baseUrl:string=' http://localhost:9090/';
  create(user:User[])
  {
  return this.http.post(this.baseUrl+'addmerchant',user);  
  }
  getMerchantByid(id:number)
  {
    return this.http.get<User[]>(this.baseUrl+id);
  }
}
